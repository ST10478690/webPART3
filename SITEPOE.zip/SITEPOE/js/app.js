document.addEventListener("DOMContentLoaded", () => {

  // Toggle this to true if you have no internet and want forms to simulate success.
  const SIMULATE_FORM_SUBMIT = true;

  // 1) LOAD PRODUCTS FROM JSON
  async function loadProducts() {
    const list = document.getElementById("product-list");
    if (!list) return;
    try {
      const res = await fetch("data/products.json");
      const items = await res.json();
      list.innerHTML = items.map(item => `
        <li class="product-item" data-name="${item.name.toLowerCase()}">
          <img src="${item.image}" alt="${item.name}" class="thumb">
          <h3>${item.name}</h3>
          <p>${item.description}</p>
        </li>
      `).join("");
    } catch (err) {
      list.innerHTML = "<li>Could not load programs.</li>";
      console.error(err);
    }
  }
  loadProducts();

  // 2) SEARCH FILTER
  const search = document.getElementById("search");
  if (search) {
    search.addEventListener("input", () => {
      const term = search.value.toLowerCase();
      document.querySelectorAll(".product-item").forEach(item => {
        const name = item.dataset.name || "";
        item.style.display = name.includes(term) ? "" : "none";
      });
    });
  }

  // 3) LIGHTBOX (click image to open)
  const lightbox = document.createElement("div");
  lightbox.id = "lightbox";
  lightbox.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.8);display:none;justify-content:center;align-items:center;z-index:9999";
  const bigImg = document.createElement("img");
  bigImg.style.maxWidth = "90%";
  bigImg.style.maxHeight = "90%";
  lightbox.appendChild(bigImg);
  document.body.appendChild(lightbox);

  document.addEventListener("click", (e) => {
    if (e.target.classList.contains("thumb")) {
      bigImg.src = e.target.src;
      bigImg.alt = e.target.alt || "";
      lightbox.style.display = "flex";
    } else if (e.target === lightbox) {
      lightbox.style.display = "none";
    }
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") lightbox.style.display = "none"; });

  // 4) FORM HANDLING (for contact/enquiry pages)
  function setupForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    const msg = document.createElement("div");
    msg.className = "form-message";
    msg.style.marginTop = "10px";
    form.appendChild(msg);

    form.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      const data = Object.fromEntries(new FormData(form).entries());
      msg.textContent = "Sending...";
      try {
        if (SIMULATE_FORM_SUBMIT) {
          // Simulate a server delay then success
          await new Promise(r => setTimeout(r, 600));
          msg.textContent = "Message sent. Thank you!";
          msg.style.color = "green";
          form.reset();
        } else {
          const res = await fetch("https://httpbin.org/post", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
          });
          if (res.ok) {
            msg.textContent = "Message sent. Thank you!";
            msg.style.color = "green";
            form.reset();
          } else {
            throw new Error("Network error");
          }
        }
      } catch (err) {
        msg.textContent = "Could not send. Try later.";
        msg.style.color = "red";
        console.error(err);
      }
    });
  }

  setupForm("contactForm");
  setupForm("enquiryForm");

});
