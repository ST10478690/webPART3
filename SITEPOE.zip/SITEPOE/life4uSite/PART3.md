# Part 3 - Evidence and Test Steps

1. Open index.html (use Live Server).
2. Search box: type "health" and see the list filter.
3. Click any program image to open the lightbox.
4. Open contact.html and submit the form (will simulate success).
5. Open enquiry.html and submit a test enquiry.
6. Files: js/app.js, data/products.json, robots.txt, sitemap.xml
