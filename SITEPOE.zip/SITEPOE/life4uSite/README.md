# Life 4 U Foundation - Web Project

## Part 3 - Interactive + SEO
Features added:
- Search / filter programs (AJAX)
- Products loaded from `data/products.json`
- Image lightbox (click to enlarge)
- Contact & Enquiry forms with validation and simulated AJAX submit
- SEO meta tags, sitemap, robots.txt
