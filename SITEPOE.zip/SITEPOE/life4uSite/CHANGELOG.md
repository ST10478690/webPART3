# Changelog

## [Unreleased] - 2025-11-17
- Added AJAX product loader and search.
- Added lightbox gallery.
- Added contact and enquiry forms with client-side validation.
- Added sitemap.xml and robots.txt.
